import json
import os

# ฟังก์ชันในการดึงพาธไฟล์ข้อมูลสำหรับแต่ละเซิร์ฟเวอร์
def get_data_path(guild_id):
    return f"data/{guild_id}.json"

# ฟังก์ชันในการโหลดข้อมูลจากไฟล์
def load_data(guild_id):
    path = get_data_path(guild_id)
    if not os.path.exists("data"):
        os.makedirs("data")
    if not os.path.exists(path):
        with open(path, "w") as f:
            json.dump({"admins": [], "tempbans": {}, "log_channel": None}, f)
    with open(path, "r") as f:
        return json.load(f)

# ฟังก์ชันในการบันทึกข้อมูลลงในไฟล์
def save_data(guild_id, data):
    with open(get_data_path(guild_id), "w") as f:
        json.dump(data, f, indent=4)

# ฟังก์ชันเพิ่มแอดมินในไฟล์
def add_admin(guild_id, user_id):
    data = load_data(guild_id)
    if user_id not in data["admins"]:
        data["admins"].append(user_id)
        save_data(guild_id, data)

# ฟังก์ชันลบแอดมินในไฟล์
def remove_admin(guild_id, user_id):
    data = load_data(guild_id)
    if user_id in data["admins"]:
        data["admins"].remove(user_id)
        save_data(guild_id, data)

# ฟังก์ชันเพื่อตรวจสอบว่าผู้ใช้เป็นแอดมินหรือไม่
def is_admin(guild_id, user_id):
    data = load_data(guild_id)
    return user_id in data["admins"]
