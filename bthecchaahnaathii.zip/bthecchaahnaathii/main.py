import discord
from discord.ext import commands, tasks
from discord import app_commands, ui
from dotenv import load_dotenv
import os, json, asyncio, datetime
from flask import Flask
from threading import Thread

# ======= HTTP SERVER (KEEP ALIVE) =======
app = Flask('')

@app.route('/')
def home():
    return "I'm alive!"

def run():
    app.run(host='0.0.0.0', port=8080)

def keep_alive():
    t = Thread(target=run)
    t.start()

# ======= LOAD ENV =======
load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")

# ======= DISCORD BOT SETUP =======
intents = discord.Intents.default()
intents.members = True
bot = commands.Bot(command_prefix="/", intents=intents)
tree = bot.tree

# ==== Utils ====
def get_data_path(guild_id):
    return f"data/{guild_id}.json"

def load_data(guild_id):
    path = get_data_path(guild_id)
    if not os.path.exists("data"):
        os.makedirs("data")
    if not os.path.exists(path):
        with open(path, "w") as f:
            json.dump({"admins": [], "tempbans": {}, "log_channel": None}, f)
    with open(path, "r") as f:
        return json.load(f)

def save_data(guild_id, data):
    with open(get_data_path(guild_id), "w") as f:
        json.dump(data, f, indent=4)

def add_admin(guild_id, user_id):
    data = load_data(guild_id)
    if user_id not in data["admins"]:
        data["admins"].append(user_id)
        save_data(guild_id, data)

def remove_admin(guild_id, user_id):
    data = load_data(guild_id)
    if user_id in data["admins"]:
        data["admins"].remove(user_id)
        save_data(guild_id, data)

async def is_admin(interaction):
    data = load_data(interaction.guild.id)
    return interaction.user.id in data["admins"]

async def send_log(guild, message):
    data = load_data(guild.id)
    log_id = data.get("log_channel")
    if log_id:
        channel = guild.get_channel(log_id)
        if channel:
            try:
                await channel.send(message)
            except:
                pass

# ==== UI View ====
class ActionView(ui.View):
    def __init__(self, target: discord.Member):
        super().__init__(timeout=None)
        self.target = target

    @ui.button(label="แบน", style=discord.ButtonStyle.danger, emoji="🔨")
    async def ban_btn(self, interaction: discord.Interaction, button: ui.Button):
        if not await is_admin(interaction):
            return await interaction.response.send_message("❌ คุณไม่มีสิทธิ์", ephemeral=True)
        await self.target.ban(reason="แบนจากปุ่ม UI")
        await interaction.response.send_message(f"🔨 แบน {self.target.mention} แล้ว", ephemeral=True)
        await send_log(interaction.guild, f"🔨 {interaction.user.mention} แบน {self.target.mention} ผ่านปุ่ม UI")

    @ui.button(label="เตือน", style=discord.ButtonStyle.secondary, emoji="⚠️")
    async def warn_btn(self, interaction: discord.Interaction, button: ui.Button):
        if not await is_admin(interaction):
            return await interaction.response.send_message("❌ คุณไม่มีสิทธิ์", ephemeral=True)
        try:
            await self.target.send(f"⚠️ คุณได้รับการเตือนจากแอดมิน {interaction.user.mention} ในเซิร์ฟ {interaction.guild.name}")
            await interaction.response.send_message(f"⚠️ เตือน {self.target.mention} เรียบร้อย", ephemeral=True)
            await send_log(interaction.guild, f"⚠️ {interaction.user.mention} เตือน {self.target.mention} ผ่านปุ่ม UI")
        except:
            await interaction.response.send_message("ไม่สามารถส่ง DM เตือนผู้ใช้นี้ได้", ephemeral=True)

# ==== Commands ====
@tree.command(name="เพิ่มแอด")
async def addadmin(interaction: discord.Interaction, user: discord.Member):
    if not await is_admin(interaction):
        return await interaction.response.send_message("❌ คุณไม่มีสิทธิ์", ephemeral=True)
    add_admin(interaction.guild.id, user.id)
    await interaction.response.send_message(f"✅ เพิ่ม {user.mention} เป็นแอดมินแล้ว", ephemeral=True)

@tree.command(name="ลบแอด")
async def removeadmin(interaction: discord.Interaction, user: discord.Member):
    if not await is_admin(interaction):
        return await interaction.response.send_message("❌ คุณไม่มีสิทธิ์", ephemeral=True)
    remove_admin(interaction.guild.id, user.id)
    await interaction.response.send_message(f"🗑 ลบ {user.mention} ออกจากแอดมินแล้ว", ephemeral=True)

@tree.command(name="แอดทั้งหมด")
async def addalladmins(interaction: discord.Interaction):
    if not await is_admin(interaction):
        return await interaction.response.send_message("❌ คุณไม่มีสิทธิ์", ephemeral=True)
    added = []
    for member in interaction.guild.members:
        if member.guild_permissions.administrator:
            add_admin(interaction.guild.id, member.id)
            added.append(member.mention)
    msg = "✅ เพิ่มแอดมิน:\n" + "\n".join(added) if added else "⚠️ ไม่พบแอดมินในเซิร์ฟเวอร์นี้"
    await interaction.response.send_message(msg)

@tree.command(name="แบน")
async def ban(interaction: discord.Interaction, member: discord.Member, reason: str):
    if not await is_admin(interaction):
        return await interaction.response.send_message("❌ คุณไม่มีสิทธิ์", ephemeral=True)
    await member.ban(reason=reason)
    await interaction.response.send_message(f"🔨 แบน {member.mention} ถาวรแล้ว | เหตุผล: {reason}", ephemeral=True)
    await send_log(interaction.guild, f"🔨 {interaction.user.mention} แบน {member.mention} | เหตุผล: {reason}")

@tree.command(name="แบนชั่วคราวใหม่")
async def tempban_new(interaction: discord.Interaction, member: discord.Member, minutes: int, reason: str):
    if not await is_admin(interaction):
        return await interaction.response.send_message("❌ คุณไม่มีสิทธิ์", ephemeral=True)
    if not interaction.guild.me.guild_permissions.ban_members:
        return await interaction.response.send_message("❌ บอทไม่มีสิทธิ์ในการแบนสมาชิก", ephemeral=True)
    until = (datetime.datetime.utcnow() + datetime.timedelta(minutes=minutes)).timestamp()
    data = load_data(interaction.guild.id)
    data["tempbans"][str(member.id)] = until
    save_data(interaction.guild.id, data)
    try:
        await member.ban(reason=reason)
        await interaction.response.send_message(f"⏳ แบน {member.mention} ชั่วคราว {minutes} นาที | เหตุผล: {reason}", ephemeral=True)
        await send_log(interaction.guild, f"⏳ {interaction.user.mention} แบนชั่วคราว {member.mention} {minutes} นาที | เหตุผล: {reason}")
    except discord.errors.Forbidden:
        await interaction.response.send_message("❌ บอทไม่มีสิทธิ์ในการแบนสมาชิกนี้", ephemeral=True)

@tree.command(name="เช็คคนโดนแบนชั่วคราว")
async def checktempbans(interaction: discord.Interaction):
    data = load_data(interaction.guild.id)
    now = datetime.datetime.utcnow().timestamp()
    msg = "⏱ ผู้ถูกแบนชั่วคราว:\n"
    for uid, ts in data["tempbans"].items():
        remain = int(ts - now)
        if remain > 0:
            mins = remain // 60
            msg += f"<@{uid}> เหลือเวลา {mins} นาที\n"
    await interaction.response.send_message(msg)

@tree.command(name="รายงาน")
async def report(interaction: discord.Interaction, user: discord.Member, reason: str):
    data = load_data(interaction.guild.id)
    for admin_id in data["admins"]:
        admin = interaction.guild.get_member(admin_id)
        if admin:
            try:
                await admin.send(f"📢 รายงานจาก {interaction.user.mention}:ถึง: {user.mention} | {reason}")
            except:
                pass
    await interaction.response.send_message("📨 ส่งรายงานถึงแอดมินทั้งหมดแล้ว", ephemeral=True)

@tree.command(name="ตั้งlog")
async def setlog(interaction: discord.Interaction, channel: discord.TextChannel):
    if not await is_admin(interaction):
        return await interaction.response.send_message("❌ คุณไม่มีสิทธิ์", ephemeral=True)
    data = load_data(interaction.guild.id)
    data["log_channel"] = channel.id
    save_data(interaction.guild.id, data)
    await interaction.response.send_message(f"📍 ตั้งค่าช่อง log เป็น {channel.mention} แล้ว")

# ==== Tempban Checker ====
@tasks.loop(seconds=60)
async def check_temp_bans():
    for filename in os.listdir("data"):
        if filename.endswith(".json"):
            try:
                gid = int(filename[:-5])
            except ValueError:
                continue
            data = load_data(gid)
            tempbans = data["tempbans"]
            now = datetime.datetime.utcnow().timestamp()
            to_unban = [uid for uid, ts in tempbans.items() if ts <= now]
            guild = bot.get_guild(gid)
            if guild:
                for uid in to_unban:
                    try:
                        user = await bot.fetch_user(int(uid))
                        await guild.unban(user, reason="หมดเวลาชั่วคราว")
                        await send_log(guild, f"✅ ปลดแบนอัตโนมัติ <@{uid}>")
                        del tempbans[uid]
                    except:
                        pass
                save_data(gid, data)

# ==== Ready ====
@bot.event
async def on_ready():
    print(f"✅ Logged in as {bot.user}")
    await tree.sync()
    check_temp_bans.start()

# ==== Start HTTP Server ====
keep_alive()

# ==== Run Bot ====
bot.run(TOKEN)
