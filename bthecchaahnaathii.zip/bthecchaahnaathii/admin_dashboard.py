import discord
from discord.ext import commands
import json

intents = discord.Intents.default()
intents.members = True
bot = commands.Bot(command_prefix="/", intents=intents)

# ฟังก์ชันที่ดึงข้อมูลจากไฟล์
def load_admin_data(guild_id):
    path = f"data/{guild_id}.json"
    with open(path, "r") as f:
        data = json.load(f)
    return data["admins"]

# คำสั่งใน Discord ที่แสดงข้อมูลแอดมิน
@bot.command(name="แสดงแอดมิน")
async def show_admins(ctx):
    admins = load_admin_data(ctx.guild.id)
    admin_mentions = [f"<@{admin_id}>" for admin_id in admins]
    await ctx.send(f"แอดมินในเซิร์ฟเวอร์นี้: {' '.join(admin_mentions)}")

bot.run("YOUR_DISCORD_TOKEN")
